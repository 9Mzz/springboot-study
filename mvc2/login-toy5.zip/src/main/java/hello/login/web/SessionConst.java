package hello.login.web;

public interface SessionConst {

  String SESSION_NAME = "memberId";

}
