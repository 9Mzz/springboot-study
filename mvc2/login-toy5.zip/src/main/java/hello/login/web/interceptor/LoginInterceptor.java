package hello.login.web.interceptor;

import java.lang.ref.ReferenceQueue;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Slf4j
public class LoginInterceptor implements HandlerInterceptor {

  public static final String LOG_ID = "logId";

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
      throws Exception {
    //uri 받아오기
    String requestURI = request.getRequestURI();
    //uuid 생성
    String uuid = UUID.randomUUID()
        .toString();
    //uuid 올리기
    request.setAttribute(LOG_ID, uuid);

    if (handler instanceof HandlerMethod) {
      HandlerMethod handlerMethod = (HandlerMethod) handler;
    }

    log.info("REQUEST [{}][{}][{}]", requestURI, uuid, handler);

    return true;
  }

  @Override
  public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
      ModelAndView modelAndView) throws Exception {
    log.info("postHandle = {}", modelAndView);
  }

  @Override
  public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
      Object handler, Exception ex) throws Exception {
    String requestURI = request.getRequestURI();
    //uuid 받아오기
    String logId = (String) request.getAttribute(LOG_ID);
    if (ex != null) {
      log.error("error", ex);
    }
    log.info("RESPOSE = [{}][{}][{}]", requestURI, logId, handler);
  }


}
